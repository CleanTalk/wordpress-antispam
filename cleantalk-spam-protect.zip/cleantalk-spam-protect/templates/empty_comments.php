<?php

// Empty comments template
