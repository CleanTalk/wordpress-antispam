<?php

$top_info_tmp = '
    <div class="apbct_settings_top_info__div">
    <p class="apbct_settings_top_info__p">%SUPPORT_BRAND%&nbsp<a target="_blank" href="%SUPPORT_LINK%">%SUPPORT_URL_TEXT%</a></p>
    <p class="apbct_settings_top_info__p">%PLUGIN_HOMEPAGE_TEXT%&nbsp<a target="_blank" href="%PLUGIN_HOMEPAGE_URL%">%PLUGIN_HOMEPAGE_URL_TEXT%</a></p>
    <p class="apbct_settings_top_info__p">%TEST_EMAIL_CHUNK%</p>
    <p class="apbct_settings_top_info__p">%TRADEMARK%</p>
    <p class="apbct_settings_top_info__p"><b style="display: inline-block; margin-top: 10px;">%FEEDBACK_REQUEST%</b></p>
    <p class="apbct_settings_top_info__p">%GET_PREMIUM_REQUEST%</p>
    </div>
';
